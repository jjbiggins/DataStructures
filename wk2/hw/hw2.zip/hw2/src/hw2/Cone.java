package hw2;

public class Cone {
   private final double radius;    // doesn't change after Cone is constructed   
   private final double height; // doesn't change after Cone is constructed

   private double iceCreamHeight;  
   
    /*
     * Constructor 
     * Initially iceCreamHeight = 0
     * 
     * If any value is less than or equal to 0, 
     * set radius and height to 1 and print "ERROR Cone"
     */
    public Cone(double radius, double height){
     
    }
    
    // Constructor
    // set iceCreamHeight to 0
    // set radius and height to 1
    public Cone(){

    }
    
    // getRadius: returns the radius of the Cone
    
    // getHeight: returns the height of the Cone
    
    // getVolume: returns the total volume of the Cone (divided by PI)

    // getIceCreamVolume: returns the volume of ice cream in the cone (divided by PI)
    
    // toString: returns a String describing the cone
    //   for example, for the cone with radius=10, height=12, iceCreamHeight=6
    //   the String will be "Cone(volume=400pi, iceCreamVolume=200pi)",
    // that is the total volume and current ice cream volume
    public String toString() {
        final String pi = "\u03c0";
        return "Cone(volume=" + getVolume() + pi + ", iceCreamVolume=" + getIceCreamVolume() + pi + ")"; 
    }

    // scoopIceCreamFrom
    // Move ice cream from other into this Cone.
    // If you would overflow this Cone, *only* move the volume
    // of ice cream that would fill this Cone to the top.
    public void scoopIceCreamFrom(Cone other){

    }

    // completely fills this Cone with ice cream
    public void fillToTop() {
            iceCreamHeight = height;	
    }
}
