
package hw2;


public class IceCreamShop {
    
    private Cone[] cones;
    private int count; //number of cones saved in the array
    
    public IceCreamShop( int maxSize ){
    	cones = new Cone[maxSize];  
       	count = 0; 
    } 
    
    // add a new cone of the given radius and height to the array
    // 
    // But, if the array is already full then just print "ERROR addCone"
    // and don't add a new cone
    public void addCone(double r, double h){

    }
    
    // if array contains at least one cone delete the last one in the array
    // otherwise do nothing
    public void deleteCone(){

    }

    // scoop ice cream from tub in order until
    // either all of the ice cream is gone or all cones have been filled
    //
    // EXAMPLE #1
    // BEFORE
    // cones {Cone(volume=10,iceCreamVolume=0), 
    //           Cone(volume=4,iceCreamVolume=0), 
    //           Cone(volume=6,iceCreamVolume=0)} 
    // tub is Cone(volume=13, iceCreamVolume=13)
    // 
    // then AFTER
    // cones {Cone(volume=10,iceCreamVolume=10), 
    //           Cone(volume=4,iceCreamVolume=3), 
    //           Cone(volume=6,iceCreamVolume=0)} 
    // tub is Cone(volume=13,iceCreamVolume=0)
    //
    // EXAMPLE #2
    // BEFORE
    // cones {Cone(volume=10,iceCreamVolume=0), 
    //           Cone(volume=4,iceCreamVolume=0), 
    //           Cone(volume=6,iceCreamVolume=0)} 
    // tub is Cone(volume=22, iceCreamVolume=22)
    // 
    // then AFTER
    // cones {Cone(volume=10,iceCreamVolume=10), 
    //           Cone(volume=4,iceCreamVolume=4), 
    //           Cone(volume=6,iceCreamVolume=6)} 
    // tub is Cone(volume=22,iceCreamVolume=2)
    public void fillConesInOrder(Cone tub) {

    }

    /*
    Helper function to check if two doubles are close enough to being equal.
    (In general, it is bad to compare doubles for exact equality with ==)
    */
    private static void check(double got, double expected) {
            final double EPSILON = 0.00001;
            if (Math.abs(got - expected) >= EPSILON) {
                    throw new RuntimeException("failed test: got "+ got + " but expected " + expected);
            }
    }

    /*
        Helper function to run a test case

        shop: the shop to work with
        tub: the ice cream tub to be scooped
        expectedVols: expected volumes of the shop's Cone after the scooping
        expectedIceCreamVols: expected ice cream volumes of shop's Cone after the scooping
        expectedTubVol: expected volume of the tub after the scooping
        expectedTubIceCreamVol: expected ice cream volume of the tub after the scooping
    */
    private static void testCase(IceCreamShop shop, Cone tub, 
                    double[] expectedVols, double[] expectedIceCreamVols,
                    double expectedTubVol, double expectedTubIceCreamVol) {
            tub.fillToTop();
            shop.fillConesInOrder(tub);
            for (int i=0; i<shop.count; i++) {
                    System.out.println(shop.cones[i].toString());
                    check(shop.cones[i].getVolume(), expectedVols[i]); 
                    check(shop.cones[i].getIceCreamVolume(), expectedIceCreamVols[i]);
            }
            System.out.println("source: "+tub.toString());
            check(tub.getVolume(), expectedTubVol);
            check(tub.getIceCreamVolume(), expectedTubIceCreamVol);
    }

        public static void main(String[] args) {
        //For these tests, the same set of cones are used for each test. They are not emptied out
        //at the begining of each test
        IceCreamShop shop = new IceCreamShop( 3 );
        shop.addCone(2, 3);
        shop.addCone(3, 1);
        shop.addCone(4, 3);
        shop.addCone(1, 2);  // will not get added because no room

        System.out.println("First cone...");
        Cone tub = new Cone(2,6);
        double[] expectedVols = {4,3,16};
        double[] expectedIceCreamVols = {4,3,1};
        testCase(shop, tub, expectedVols, expectedIceCreamVols, 8, 0);
        System.out.println("...First test passed\n");

        System.out.println("Second cone...");
        Cone tub2 = new Cone(6,6);
        double[] expectedVols2 = {4,3,16};
        double[] expectedIceCreamVols2 = {4,3,16};
        testCase(shop, tub2, expectedVols2, expectedIceCreamVols2, 72, 57);
        System.out.println("...Second test passed\n");

        System.out.println("Third cone...");
        shop.deleteCone(); // delete 3rd Cone
        shop.deleteCone(); // delete 2nd Cone
        shop.addCone(9, 1);
        Cone tub3 = new Cone(1, 6);
        double[] expectedVols3 = {4,27};
        double[] expectedIceCreamVols3 = {4,2};
        testCase(shop, tub3, expectedVols3, expectedIceCreamVols3, 2, 0);
        System.out.println("...Third test passed\n");

        /*
        Optional (but recommended): you can add more tests here
        */
    }

}
