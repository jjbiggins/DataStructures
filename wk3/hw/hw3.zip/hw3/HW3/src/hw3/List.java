/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw3;

interface List {
    
    Object remove(int i);

    void append(Object d);

    Object get(int i);

    void move(int i, int j);

    Object[] toArray();
}
