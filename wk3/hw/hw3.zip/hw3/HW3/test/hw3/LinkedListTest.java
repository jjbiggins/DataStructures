/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw3;

import org.junit.Test;
import static org.junit.Assert.*;

public class LinkedListTest {
		
		public LinkedListTest() {
		}

		@Test
		public void testRemove1() {
			List ll = new LinkedList();
			ll.append(100);
			assertEquals(100, ll.remove(0));
		}

		@Test
		public void testRemoveBigger() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			assertEquals(300, ll.remove(2));
			assertEquals(200, ll.remove(1));
			assertEquals(400, ll.remove(1));
		}
		
		@Test
		public void testRemoveAndGet() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			assertEquals(300, ll.remove(2));
			assertEquals(200, ll.get(1));
			assertEquals(400, ll.get(2));
		}
		
		@Test
		public void testRemoveGetAppend() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			assertEquals(300, ll.remove(2));
			assertEquals(400, ll.get(2));
			ll.append(500);
			ll.append(600);
			assertEquals(400, ll.remove(2));
			assertEquals(500, ll.get(2));
			assertEquals(600, ll.remove(3));
		}

		/**
		 * Test of get method, of class LinkedList.
		 */
		@Test
		public void testGet1() {
			List ll = new LinkedList();
			ll.append(100);
			assertEquals(100, ll.get(0));
		}
		
		/**
		 * Test of get method, of class LinkedList.
		 */
		@Test
		public void testGetBigger() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			assertEquals(100, ll.get(0));
			assertEquals(200, ll.get(1));
			assertEquals(300, ll.get(2));
			assertEquals(400, ll.get(3));
		}

		/**
		 * Test of move method, of class LinkedList.
		 */
		@Test
		public void testMove2Backward() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.move(0, 1);
			assertEquals(200, ll.get(0));
			assertEquals(100, ll.get(1));
		}
		
		@Test
		public void testMove2Forward() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.move(1, 0);
			assertEquals(200, ll.get(0));
			assertEquals(100, ll.get(1));
		}

		@Test
		public void testMoveMoreForward() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			ll.append(500);
			ll.move(4, 0);
			assertEquals(500, ll.get(0));
			assertEquals(100, ll.get(1));
			assertEquals(200, ll.get(2));
			assertEquals(300, ll.get(3));
			assertEquals(400, ll.get(4));
			ll.move(3, 1);
			assertEquals(500, ll.get(0));
			assertEquals(300, ll.get(1));
			assertEquals(100, ll.get(2));
			assertEquals(200, ll.get(3));
			assertEquals(400, ll.get(4));
		}
		
		@Test
		public void testMoveMoreBackward() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			ll.append(500);
			ll.move(0, 4);
			assertEquals(200, ll.get(0));
			assertEquals(300, ll.get(1));
			assertEquals(400, ll.get(2));
			assertEquals(500, ll.get(3));
			assertEquals(100, ll.get(4));
			ll.move(1, 3);
			assertEquals(200, ll.get(0));
			assertEquals(400, ll.get(1));
			assertEquals(500, ll.get(2));
			assertEquals(300, ll.get(3));
			assertEquals(100, ll.get(4));
		}
		
		@Test
		public void testMoveBackAndForth() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			ll.append(500);
			ll.move(1, 3);
			ll.move(4, 3);
			ll.move(0, 2);
			assertEquals(300, ll.get(0));
			assertEquals(400, ll.get(1));
			assertEquals(100, ll.get(2));
			assertEquals(500, ll.get(3));
			assertEquals(200, ll.get(4));
		}
		
		@Test
		public void testAll() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			ll.append(500);
			ll.move(1, 3);
			assertEquals(200, ll.remove(3));
			ll.append(600);
			ll.move(4, 1);
			assertEquals(100, ll.remove(0));
			assertEquals(400, ll.remove(2));
			ll.move(2, 0);
			assertEquals(500, ll.get(0));
			assertEquals(600, ll.get(1));
			assertEquals(300, ll.get(2));
		}

		@Test
		public void testToArrayEmpty() {
			List ll = new LinkedList();
			Object[] actual = ll.toArray();
			assertArrayEquals(new Object[0], actual);
		}
		
		@Test
		public void testToArray1() {
			List ll = new LinkedList();
			ll.append(100);
			Object[] actual = ll.toArray();
			Object[] expected = { 100 };
			assertArrayEquals(expected, actual);
		}
		
		@Test
		public void testToArrayMore() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			ll.append(500);
			Object[] actual = ll.toArray();
			Object[] expected = { 100, 200, 300, 400, 500 };
			assertArrayEquals(expected, actual);
		}
		
		@Test
		public void testAllAndToArray() {
			List ll = new LinkedList();
			ll.append(100);
			ll.append(200);
			ll.append(300);
			ll.append(400);
			ll.append(500);
			ll.move(1, 3);
			ll.remove(3);
			ll.append(600);
			ll.move(4, 1);
			ll.remove(0);
			ll.remove(2);
			ll.move(2, 0);
			Object[] actual = ll.toArray();
			Object[] expected = { 500, 600, 300 };
			assertArrayEquals(actual, expected);
		}
}
