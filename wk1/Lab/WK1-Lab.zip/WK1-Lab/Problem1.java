public class Problem1 {

    public static void main(String[] args) {
      double hello = "Hello Class!";
        //Print out the variable 'hello'
      
      
    }
}