public class Problem2 {
    
        public static void main(String[] args) {
             
            int n = 16;
            for(int i = 1; _______ ; ________)
            {
              if(i%3 == 0 || i%5 == 0)
              {
                  //INSERT FIZZ and BUZZ Print statements here
              }
              else
              {
                System.out.print(i);
              }
              
            }
        }
    }