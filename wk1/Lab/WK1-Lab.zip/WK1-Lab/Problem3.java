public class Problem3 {
    public static void main(String[] args){
        int a = 14;
        int b = 28;
      
        //Create a new calculator Object with calc name of "My-Calc"
        
        double added = calc.add(a, a);
       
        double subtracted = calc.substract(b, a);
        double squared = calc.squared(a);
        double addTen = calc.addTen(a);
        
         //Print out the calc name here  
      
        System.out.println(added);
         if(added == b){
            System.out.println(true);
        }
        System.out.println(subtracted);
        System.out.println(squared);
        System.out.println(addTen);
    }
    
    static class Calculator{
        private String calcName;
        
        //Set a calculator name in the constructor
        public Calculator(String calcName){
            this.calcName = calcName;
        }
        
        //Add 2 numbers
        public double add(double a, double b){
            
        }
        
        //Subtract 2 numbers, write method
         //Method name, "subtract"
     
        
        //Add 10 to any given number
         //Method name, "addTen"

        
         //Write the top part of the method. 
         //Method name is "squared"
        //Square the number e.g. 4^2 = 16
        ______________{
            return Math.pow(a, 2);
        }
        
        //Print out the calculator name
         //What is the return type here?
         //How do you print out the calculator name? Fill in the blanks!
        public ______________ getCalcName(){
            System.out.println("This is the calc name: " + ____________);
        }
    }
}
